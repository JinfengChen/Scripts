echo "using g++ or make to compile the source file, g++ automaticly generate .o file and link the file to compile"
g++ -o oppclass main.cpp rectangle.cpp
make

